import React,{Component} from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { Route, Link ,Redirect,BrowserRouter as Router} from 'react-router-dom';
import Test from './Test';
import searchicon from './img/images.png';


class AdminMap extends Component{

    componentDidMount(){
        var formJson;

        fetch('http://localhost:8080/admionmap/',{method:'GET'})
        .then(response => response.json())
        .then((response) => {
            console.log('response',response);
            formJson = response;
           this.setState((state) => {
               state.formJson = formJson
            });
            this.setState({dataReady : true});
           console.log('json1',this.state.formJson)
          });

    }

}