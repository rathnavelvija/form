import React from 'react';
import Input from './Input'


class Section extends React.Component {
  constructor(props){
    super(props);
    this.state={
        secname : '',
       inputList: [],
       fldname:'',
       fldtype:'',
       v1:[],
     fldarray:[],

    };

    this.onAddBtnClick = this.onAddBtnClick.bind(this);
    this.handleSecname=this.handleSecname.bind(this);
    this.childValues=this.childValues.bind(this);

    }
    handleSecname(event){

        this.setState({secname: event.target.value});
    }
    childValues(fieldName,fieldType){
        // console.log("hello", fieldname,fieldtype);

       this.setState({fldname :fieldName, fldtype:fieldType}, ()=> {
        //    console.log("*******",this.state);
       });     
       this.props.sectionConfirm(this.state.secname, fieldName,fieldType);
    }

    onAddBtnClick(event) {



     //  alert(this.state.fldname);
      //  this.props.formtrigger(this.state.fldname,this.state.fldtype,this.state.secname);
      this.props.formtrigger(this.state.secname,this.state.fldarray);

        const inputList = this.state.inputList;

        this.setState({
            inputList: inputList.concat(<Input key={inputList.length} dropDown={this.props.dropDown} parenttrigger={this.childValues} />)
        });


        const fldarray=[...this.state.fldarray,{fieldname:this.state.fldname,fieldtype:this.state.fldtype}];

        this.setState({fldarray});

        //console.log("fieldArray in section",this.state.fldarray);
    }


    render() {
        return (
<div className="container">
<div className="form-group"></div>
<div className="card">

<div style={{border:"groove"}}>
<div style={{paddingTop:"10px",paddingRight:"50px",paddingBottom:"10px"}} className="row col-sm-6">
<label>Section Name:</label>
<input type="text" name="secname" value={this.state.secname} onChange={this.handleSecname} placeholder="Sectionname"/>
<div className="col-sm-2">

</div>
</div>

<button type="button"style={{paddingTop:"10px"}} className="btn btn-small btn-primary float-right" onClick={this.onAddBtnClick} value = "Addfield">Add Fields</button>
{this.state.inputList.map(function(input, index) {
return input;

})}
</div>
<div className="text-left row col-sm-4"> </div>
</div>

</div>
);
}
}

export default Section;