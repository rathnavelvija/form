import React from  'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function footer(){

return(
<footer className="page-footer font-small blue fixed-bottom ">
<div className="allign1">
<div className="footer-copyright text-center py-3 color1 ">Copyright © 2020 Tata Consultancy Services
</div>
  </div>
  </footer>
 

);

};

export default footer;
