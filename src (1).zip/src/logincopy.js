import React, { Component, useLayoutEffect } from 'react';
import './App.css';
//import { Redirect } from 'react-router-dom';
import {BrowserRouter as Router,Redirect, Route, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import userlogo from './img/logo2.png';
//import Landing from './Landing';


window.$name="meenaa";
class logincopy extends React.Component {

    constructor(props){
    super(props);
    this.state={
        username : ' ',
        password:'',
        redirect:false,
        role:'',
        role1:''
    };
    this.clickHandler = this.clickHandler.bind(this);
    this.handleusername =this.handleusername.bind(this);
    this.handlePassword=this.handlePassword.bind(this);
    }
handleusername(event)
{
    this.setState({username: event.target.value});
}


clickHandler(event){

        fetch('http://localhost:8080/auth',{method:'POST',body:JSON.stringify({userId:this.state.username,password:this.state.password})})
         .then(response => response.json())
        .then( (response) =>{console.log('response',response)

        if(response==="User authendication failed")
         {
            alert("Invalid Credentials");
         }
else{
    const role1='';
    this.setState(state => {
        state.role1  = state.role
    })

    this.setState({redirect:true,role1 : this.state.role});
    this.state.role=response;
//role1=response;
   // this.props.roletrigger(this.state.role);
    console.log('user role is',this.state.role);
   
}
   
    }
        )

        
    event.preventDefault();
    }

handlePassword(event)
    {
        this.setState({password: event.target.value});
    }


    shouldComponentUpdate() {
        return true;
    }

   

    render(){
        console.log("Before redirect",this.state);
        if(this.state.redirect){
            console.log("****",this.state.redirect);

        
           const rolee=this.state.username;
            
			return(

                <Redirect to={{
                    pathname: '/landing',
                    state: { role: rolee}
                }}
        />

        
                    // <Redirect to={"/landing/"+this.state.role}
     

           )
      
	  }
	  	
return(
<div style={{"background":"white"}}>
     <div className="login-border" style={{marginTop:"170px"}} >
     <div className="allign">
     <h3 className="user-login">User Login </h3>    
     <img src={userlogo} alt="userlogo" width="120" height="120" padding="10px" ></img>
        <form name="loginForm" className="login-form" onSubmit={this.clickHandler}>
    
        <div className="form-group">
            <label>Username  </label> 

            <input type="text" style={{marginLeft:"10px"}} name="username" value={this.state.handleusername} onChange={this.handleusername} className="form-control1" placeholder="Username"  required=""/>
        </div>

        <div className="form-group">
           <label>Password  </label>
            <input type="password" style={{marginLeft:"10px"}} name="password" value={this.state.handlePassword} onChange={this.handlePassword} className="form-control1" placeholder="Password"  required=""/>
         </div>

        <button type="submit" className="login-btn" value="Submit" >Login</button>
        
     
        </form>
      </div>
     </div>
     
</div>  

);
    }


}

export default logincopy;


