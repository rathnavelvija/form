import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';


var admin = (props) =>
{
    
const url =  "createForm/" + props.formName + "/" + props.formId;
//this.props.gridTrigger(this.props.formId,this.props.formName);

return(
    <div className="item1">
        <div className="text-center">{props.formName} </div>
        
    <center>
    <button className="btn btn-sm text-center btn-primary btn11" onClick={()=>{props.click(props.formName, props.formId)}}><a href={url} style={{color:"white"}}>Edit </a></button>
    <button style={{marginLeft:"10px"}} className="btn btn-sm text-center btn-primary btn11" onClick={()=>{props.click(props.formName, props.formId)}}><a href={url} style={{color:"white"}}> Map</a></button>


    
        </center>                     
</div>
);

}

export default admin;

