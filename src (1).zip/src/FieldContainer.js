import React, { Component,Fragment } from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import * as ReactDOM from 'react-dom'
import $ from 'jquery';


import {AgGridReact} from 'ag-grid-react';




class FieldContainer extends Component {
	constructor(props) {
    super(props);
    this.state = {
					ename: "",
					etype: "",
					edisplayname: "",
					entdesc: "",
					fields:[],
					sections:[],
					msg:"",
					msgs:"",
					sectionhandler :[{
						secname:"hello",
						fieldhandler:[],
					}],
					fieldhandler:[{fname: "",
								fdesc: "", 
								ftype: "",
								referenceEntityName: "",
								referenceEntityField: "",
								fdisname: "",
								defalt: "",
								Keyfield:false,
								nullable:false,
								flist:false,
								fsearch:false,
								fdisplay:false
								}],
					ftypeList:[],
					linkEntList:[{myVal:[]}],
					linkEntdisable:[{myVal:false}],
					defPattern:[{myVal:{pattern:"[a-zA-Z0-9]*",title:""}}],
					showtable:false,
					showform:true
				};
	this.handleNext = this.handleNext.bind(this);
	this.handleBack = this.handleBack.bind(this);
	this.handleSubmit = this.handleSubmit.bind(this);
	this.handleEntityDetChange = this.handleEntityDetChange.bind(this);
  }
  
  handleEntityDetChange(event)
  {
	if(event.target.name===("ename")){
		var ename=event.target.value;
		var firstchar=ename.charAt(0);
		if(ename === ' ' || firstchar === '_'){}
		else if(firstchar<='9' && firstchar>='0'){}
		else if((ename) === (this.state.ename+' ')){}
		else{
			this.setState({ename: event.target.value});}
	}
	else{
	  this.setState({
		  [event.target.name]:event.target.value
	  });
	}
  }
  
  
  handleRespectiveChange = idx => evt => {
	 const newfieldhandler = this.state.fieldhandler.map((fieldhandler, sidx) => {
      if (idx !== sidx) {console.log('idx',idx);console.log('sidx',sidx); return fieldhandler;}
	  if(evt.target.name === 'Keyfield'){
		const  booleanTemp = this.state.fieldhandler[idx].Keyfield;
		return { ...fieldhandler, [evt.target.name]: !booleanTemp };
	  }
	  else if(evt.target.name === 'nullable'){
		const  booleanTemp = this.state.fieldhandler[idx].nullable;
		return { ...fieldhandler, [evt.target.name]: !booleanTemp };
	  }
	  else if(evt.target.name === 'flist'){
		const  booleanTemp = this.state.fieldhandler[idx].flist;
		return { ...fieldhandler, [evt.target.name]: !booleanTemp };
	  }
	  else if(evt.target.name === 'fsearch'){
		const  booleanTemp = this.state.fieldhandler[idx].fsearch;
		return { ...fieldhandler, [evt.target.name]: !booleanTemp };
	  }
	  else if(evt.target.name === 'fdisplay'){
		const  booleanTemp = this.state.fieldhandler[idx].fdisplay;
		return { ...fieldhandler, [evt.target.name]: !booleanTemp };
	  }
	  else if(evt.target.name===("fname")){
		  var fname = evt.target.value;
		  var lastChar = fname[fname.length -1];
		  var firstchar=fname.charAt(0);
		if(lastChar === ' ' || firstchar === '_'){
			return fieldhandler;
			}
		else if(firstchar<='9' && firstchar>='0'){
			return fieldhandler;
			}
		else{
			return { ...fieldhandler, [evt.target.name]: evt.target.value };
		}
	  }
	 
	  else if(evt.target.name === 'defalt' ){
		 const ftyp = this.state.fieldhandler[idx].ftype;
		 if(ftyp ==='Short Id' || ftyp ==='Long Id' || ftyp ==='Amount' || ftyp ==='Rate' 
		 || ftyp ==='Percentage' || ftyp ==='Numeric_3' || ftyp ==='Numeric_10'){
		 var tObj = this.state.defPattern;
			tObj[idx].myVal.pattern="[0-9]*";
			tObj[idx].myVal.title="Numeric only";
			this.setState({defPattern : tObj});
		 return { ...fieldhandler, [evt.target.name]: evt.target.value };
		 }
		  else{
			return { ...fieldhandler, [evt.target.name]: evt.target.value };
		}
		}
	  else{
		  if(evt.target.name === 'ftype' || ftyp ==='Long Id' || ftyp ==='Amount' || ftyp ==='Rate' 
		 || ftyp ==='Percentage' || ftyp ==='Numeric_3' || ftyp ==='Numeric_10'){
			  var ftyp = evt.target.value;
			  if(ftyp ==='Short Id'){
					var tObj = this.state.defPattern;
					tObj[idx].myVal.pattern="[0-9]*";
					tObj[idx].myVal.title="Numeric only";
					this.setState({defPattern : tObj});
				}
				else{
				var tObj = this.state.defPattern;
				tObj[idx].myVal.pattern="[a-zA-Z0-9]*";
				tObj[idx].myVal.title="";
				this.setState({defPattern : tObj});
				}
						if(ftyp === 'Domain' ||	ftyp === 'Master' 
								|| ftyp === 'Reference' || ftyp === 'Business'
								){
							var tObj = this.state.linkEntdisable;
							tObj[idx].myVal=true;
							this.setState({linkEntdisable : tObj});
							var self = this;
							var url2 = "http://10.145.40.162:8082/NewProject/retEnt/"+evt.target.value;
						$.ajax({
							type: "GET",
							url:url2, 
							contentType: "application/json; charset=utf-8",
							dataType: "json",
							success: function(data) {
								var fromApi = data.map((field,i) => { return {id: data[i].id, value: data[i].EntityName} });
								const linkEnt = Object.assign([],self.state.linkEntList);
								linkEnt[idx].myVal = fromApi;
								self.setState({ linkEntList: linkEnt });
							},
							error:function(e){
								console.log("Error >>  "+e)}
							})
						}
						else if(evt.target.name === 'ftype'){
							var tObj = this.state.linkEntdisable;
							tObj[idx].myVal=false;
							this.setState({linkEntdisable : tObj});
							const linkEnt = Object.assign([],this.state.linkEntList);
							linkEnt[idx].myVal = [];
							this.setState({ linkEntList: linkEnt });
						}
					}
				return { ...fieldhandler, [evt.target.name]: evt.target.value };
			}
	});

    this.setState({ fieldhandler: newfieldhandler });
  };
  
  handleAddNewSection = () => {
	this.setState({
		sectionhandler: this.state.sectionhandler.concat([{
													secname:"hello", 
													fieldhandler: this.state.fieldhandler}])});
}
  handleAddNewField = () => {
    this.setState({
      fieldhandler: this.state.fieldhandler.concat([{fname: "",
													fdesc: "", 
													ftype: "",
													referenceEntityName: "",
													referenceEntityField: "",
													fdisname: "",
													defalt: "",
													Keyfield:false,
													nullable:false,
													flist:false,
													fsearch:false,
													fdisplay:false
													}]),
	  linkEntList: this.state.linkEntList.concat({myVal:[]}),
	  linkEntdisable: this.state.linkEntdisable.concat({myVal:false}),
	  defPattern: this.state.defPattern.concat({myVal:{pattern:"[a-zA-Z0-9]*",title:""}})
    });
  };
  
  handleRemoveField = idx => () => {
    this.setState({
      fieldhandler: this.state.fieldhandler.filter((s, sidx) => idx !== sidx),
	  linkEntList: this.state.linkEntList.filter((s, sidx) => idx !== sidx),
	  linkEntdisable: this.state.linkEntdisable.filter((s, sidx) => idx !== sidx),
	  defPattern: this.state.defPattern.filter((s, sidx) => idx !== sidx)
    });
  };

  
  componentDidMount()
  {
			var self = this;
			$.ajax({
					type: "GET",
					url: "http://10.145.40.162:8082/NewProject/dataType",
					contentType: "application/json; charset=utf-8",
					dataType: "json",
					success: function(data) 
					{
      					var teamsFromApis = data.map((entity,a) => { return {id: data[a].id, value: data[a].datatype,descr: data[a].desc} });
						self.setState({ ftypeList: teamsFromApis });
					},
					error:function(e)
					{
						//alert(e.message);
					}
				})

  }
 
  
  handleSubmit(event) {

	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;
	var myName = sessionStorage.getItem('userData'); 
	var obj1 = new Object();
	obj1.ename=this.state.ename;
	obj1.id_appln = (JSON.parse((myName)).map).appId; 
	obj1.etype=this.state.etype;
	obj1.edisplayname=this.state.edisplayname;
	obj1.entdesc=this.state.entdesc;
	obj1.fields=this.state.fieldhandler;  
	obj1.sections=this.state.sectionhandler;
	//this.setState({msg:''});
	console.log("Submit Clicked");
	console.log(obj1);
   	var self=this;
	
	$.ajax({
		type: "POST",
		url: "http://10.145.40.162:8082/NewProject/creations",   //Endpoint URL
		data: JSON.stringify(obj1) ,
		contentType: "application/json; charset=utf-8",
		dataType: "json",
		success: function(data) {
									console.log(data);
										/* if(data.substring(0,6) === "EXISTS"){
											self.setState({mymsgcolor: "red"});
											self.setState({msgs: "Failed-Table Already Exist!"});
										} */
										if(data.substring(0,5) === "Table"){
											self.setState({mymsgcolor: "green"});
											self.setState({msgs: "Table Created Successfully"});
											self.setState({showform:false});
											self.setState({showtable:true});
										}
										/*else if(data.substring(0,7) === "Display"){
											self.setState({mymsgcolor: "red"});
											self.setState({msgs: "Failed-Table Display Name Exist!"});
										 } */
								},
		error:function(e){                             //If error occurs
				console.log("Error >> "+e.message);
				}
	})
	
    event.preventDefault();
	
  }
  
  handleNext(event) {
	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;
	this.setState({msg:''});
	var obj = new Object();
	obj.ename=this.state.ename;
	obj.etype=this.state.etype;
	obj.edisplayname=this.state.edisplayname;
	obj.fields=this.state.fieldhandler;  
	obj.sections=this.state.sectionhandler;
	console.log("Next Clicked");
	console.log(obj);
   	var self=this;
	$.ajax({
		type: "POST",
		url: "http://10.145.40.162:8082/NewProject/next",   //Endpoint URL
		data: JSON.stringify(obj) ,
		contentType: "application/json; charset=utf-8",
		dataType: "json",
		success: function(data) {
									console.log(data);
										if(data['enameStat'] === 'Failed'){
											self.setState({msg:data['enameMessage']});
											self.setState({mymsgcolor:"red"});
										}
										else if(data['edisplaynameStat'] === 'Failed' ){
											self.setState({msg:data['edisplayMessage']});
											self.setState({mymsgcolor:"red"});
										}
										else if(data['edisplaynameStat'] === 'Success' 
														&& data['enameStat'] === 'Success'){
											self.setState({showtable:true});
											self.setState({showform:false});
										}
										
								},
		error:function(e){                             //If error occurs
				console.log("Error >> "+e.message);
				}
	})
	
    event.preventDefault();
	
  }
  
   handleBack(event) {
	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;
	
	this.setState({showtable:false,showform:true});
	event.preventDefault();
	
  }
  

  render() {
	if(this.state.showform){
    return (
     <form onSubmit={this.handleNext}>
		<div className="msgdisplay">
			<font color={this.state.mymsgcolor} >{this.state.msg}</font><br/>
		</div>
	 <div className="fullform">
	 <div> 
		<fieldset className = "entity_det_container">
		<legend>ENTITY DETAILS</legend>
			<table>
			<tbody>
				<tr>
					<td>
						<table className="insidetable">
							<tbody>
								<tr>
									<td>
										<label>Entity Type<font id="color">*</font></label>
									</td>
									<td>
										<select required name="etype" value={this.state.etype} onChange={this.handleEntityDetChange} required="true">
											<option defaultValue value="" style={{display: 'none'}} >Select Entity Type</option>
											<option key="a" value="Domain">Domain</option>
											<option key="b" value="Reference">Reference</option>
											<option key="c" value="Business">Business</option>
											<option key="d" value="Master">Master</option>
										</select>
									</td>
									<td>
										<label>Entity Description<font id="color">*</font></label>
									</td>
									<td>
										<input type="text" name="entdesc" value={this.state.entdesc} 
											onChange={this.handleEntityDetChange} required/>
									</td>
								</tr>
								<tr>
									<td>
										<label>Entity Name<font id="color">*</font></label>
									</td>
									<td>
										<input type="text" name="ename" value={this.state.ename} onChange={this.handleEntityDetChange} pattern="[a-zA-Z0-9_\s]*" required/>
									</td>
									<td>
										<label>Entity Display Name<font id="color">*</font></label>
									</td>
									<td>
										<input type="text" name="edisplayname" value={this.state.edisplayname} 
											onChange={this.handleEntityDetChange} pattern="[a-zA-Z0-9\s]*" required/>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
			</table>
		</fieldset>
	 </div>
	 <button className="addfield-button" title="Add section" type="button" onClick={this.handleAddNewSection}>+</button>

	 {/* {this.state.sectionhandler.map((sectionhandler, idx) => (

	<input type="text" name="fname" value={sectionhandler.secname} onChange={this.handleRespectiveChange(idx)} pattern="[a-zA-Z0-9_\s]*" required/> */}

	 {this.state.fieldhandler.map((fieldhandler, idx) => (
		<div key={idx}>
		<fieldset className = "field_det_container">
		<legend>FIELD-{idx+1} DETAILS</legend>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
		 <button type="button" title="Removes this field" className="btn" onClick={this.handleRemoveField(idx)}><font className="fa fa-trash"/></button>
		<table>
		<tbody>
		<tr>
			<td>
				<table className="insidetable1">
				<tbody>
					<tr>
						<td>
							<label>Field Name<font id="color">*</font></label>
						</td>
						<td>
							<input type="text" name="fname" value={fieldhandler.fname} onChange={this.handleRespectiveChange(idx)} pattern="[a-zA-Z0-9_\s]*" required/>
						</td>
						<td>
							<label>Field Display Name<font id="color">*</font></label>
						</td>
						<td>
							<input type="text"name="fdisname" value={fieldhandler.fdisname} onChange={this.handleRespectiveChange(idx)} pattern="[a-zA-Z0-9\s]*" required/>
						</td>
					</tr>
					<tr>
						<td>
							<label>Field Type<font id="color">*</font></label>
						</td>
						<td>
							<select required name="ftype" value={this.state.fieldhandler[idx].ftype} onChange={this.handleRespectiveChange(idx)}>
								<option defaultValue value="" style={{display: 'none'}}>--select--</option>
  					       <option>helo</option>
							</select>
						</td>
						<td>
							<label>Linked Entity</label>
						</td>
						<td>
							<select  name="referenceEntityName" value={this.state.fieldhandler[idx].referenceEntityName} onChange={this.handleRespectiveChange(idx)} required={this.state.linkEntdisable[idx].myVal}>
							<option defaultValue value="" style={{display: 'none'}}>--select--</option>
  					        {this.state.linkEntList[idx].myVal.map((x) => 
							<option key={x.id} value={x.value}>{x.value}</option>)
							}
						    </select>
						</td>
					</tr>
					<tr>
						<td>
							<label>Field Description<font id="color">*</font></label>
						</td>
						<td>
							<input type="text" name="fdesc" value={fieldhandler.fdesc} onChange={this.handleRespectiveChange(idx)} required />
						</td>
						<td>
							<label>Default Value</label>
						</td>
						<td>
							<input type="text" name="defalt" value={fieldhandler.defalt} 
								onChange={this.handleRespectiveChange(idx)}
									pattern={this.state.defPattern[idx].myVal.pattern} 
										title={this.state.defPattern[idx].myVal.title}/>
						</td>
					</tr>
					<tr>
						<td>
							<label>Key Field</label>
						</td>
						<td>
							<label className="keyfield-toggle">
								<input type="checkbox" name="Keyfield"  
									onChange={this.handleRespectiveChange(idx)} 
										checked={this.state.fieldhandler[idx].Keyfield}/>
								<div className="slider"></div>
							</label>
						</td>
						<td>
							<label>Nullable</label>
						</td>
						<td>
							<label className="nullable-toggle">
								<input type="checkbox" name="nullable"  
									onChange={this.handleRespectiveChange(idx)} 
										checked={this.state.fieldhandler[idx].nullable}/>
								<div className="slider"></div>
							</label>
						</td>
					</tr>
				</tbody>
				</table>
			</td>
		</tr>
		</tbody>
		</table>
		 </fieldset>
		</div>
	 ))}
	 	{/* ))	} */}
	<input type="submit" id="create-button" value="Next" /><span>   </span>
	<button className="addfield-button" title="Add field" type="button" onClick={this.handleAddNewField}>+</button>
	</div>
    </form>
	)
  }//if ends here
   else if(this.state.showtable){
	 return(
	 <div>
	 <div className="msgsdisplay">
			<font color={this.state.mymsgcolor} >{this.state.msgs}</font><br/>
	</div>
	 <div className="fulltable">
		<table id="customers"> 
			<tbody>
				<tr>
					<th>Field Name</th>
					<th>List</th>
					<th>Search</th>
					<th>Display</th>
				</tr>
				 {this.state.fieldhandler.map((fieldhandler, idx) => (
				<tr key={idx}>
					<td>
						{this.state.fieldhandler[idx].fdisname}
					</td>
					<td>
						<input type="checkbox" name="flist" 
							checked={this.state.fieldhandler[idx].flist} 
								onChange={this.handleRespectiveChange(idx)}/>
					</td>
					<td>
						<input type="checkbox" name="fsearch" 
							checked={this.state.fieldhandler[idx].fsearch} 
								onChange={this.handleRespectiveChange(idx)}/>
					</td>
					<td>
						<input type="checkbox" name="fdisplay" 
							checked={this.state.fieldhandler[idx].fdisplay} 
								onChange={this.handleRespectiveChange(idx)}/>
					</td>
				</tr>
				))}
			</tbody>
		</table>
	 		<button type="submit" id="back-button" onClick={this.handleBack}>Back</button>
			<button type="submit" id="submitt-button" onClick={this.handleSubmit} >Create</button>
			 </div> 
		</div>
	  )
  }
  }
}


export default FieldContainer;
