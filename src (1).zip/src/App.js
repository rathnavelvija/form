import React, { Component } from 'react';
import { Route, Switch, Link ,Redirect, BrowserRouter as Router} from 'react-router-dom';
import './App.css';
import './App1.css'
//import Loginform from './login';
import Loginform from './logincopy';
//import fieldadd from './addfields';
import Header from './header';
import Footer from './footer';
import CreateForm from './CreateForm';
import Landing from './Landing';
import FieldContainer from './FieldContainer';
import DynamicForm from './DynamicForm';
import dataGrid from './grid';

function loginform() {
     return <div style={{ backgroundColor:'lavender' }} >        
                 <Loginform />
          </div>;
   }

   
function createform() {
   return <div>        
         <CreateForm/> 
        </div>;
 }

    
function landing() {
  return <div>        
        <Landing/> 
       </div>;
}
function varsh() {
   return <div>        
         <FieldContainer/> 
        </div>;
 }

class App extends Component {
    render() {
    return (
       <div>
          <Router>
             <Header/>   
      <div  className = 'dd-app-js'>      
       <Route exact path="/" component={loginform} />
       </div>   

       <div  className = 'dd-app-js'>      
       <Route exact path="/create" component={createform} />
       </div> 
       <div  className = 'dd-app-js'>      
       <Route exact path="/create/:role" component={createform} />
       </div>   
       <div  className = 'dd-app-js'>      
       <Route exact path="/landing" component={Landing} />
       </div>  
       <div  className = 'dd-app-js'>      
       <Route exact path="/varsh" component={FieldContainer} />
       </div>  
       <div  className = 'dd-app-js'>      
       <Route exact path="/dataentry" component={DynamicForm} />
       </div>  
       <div  className = 'dd-app-js'>      
       <Route exact path="/viewGrid/:role/:formName/:formId" component={dataGrid} />
       </div>  
       <div  className = 'dd-app-js'>      
       <Route exact path="/createForm/:formName/:formId" component={createform} />
       </div>  
       <div  className = 'dd-app-js'>      
       <Route exact path="/dynamicForm/:formId" component={DynamicForm} />
       </div>  
        <Footer/>
       </Router>
      </div>
    );
    
    }
  
}

export default App;

