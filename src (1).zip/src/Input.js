import React from 'react';


class Input extends React.Component {

    constructor(props){
        super(props);
        this.state={
            fieldname : '',
            fieldtype : '',
            dropDown:''
    
        };
    
        this.setFieldNameHandler=this.setFieldNameHandler.bind(this);
    
        this.setFieldTypeHandler=this.setFieldTypeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    
        }
      
        setFieldNameHandler(event) {  
            this.setState({fieldname: event.target.value});
    
        }
        setFieldTypeHandler(event){
            console.log('drop down ',event.target.value);
            this.setState({
                fieldtype: event.target.value });
    
        }
        submitHandler(){
    
            this.props.parenttrigger(this.state.fieldname,this.state.fieldtype);
    
            console.log("input name ",this.state.fieldname);
            console.log("input type",this.state.fieldtype);  
        }
    
    render() {
        return (
            <div className="row">
            <div> 
                <label className="labels">Enter Label name</label>
                <input type="text" name="fieldname" value={this.state.fieldname} onChange={this.setFieldNameHandler}  placeholder="Fieldname"/>
            </div>  
            <div>   
            <label className="labels">Enter Field Type</label>
            <select value={this.state.fieldtype}  onChange={this.setFieldTypeHandler}>
                <option></option>
                {this.props.dropDown.map((e, key) => {
                  return <option key={key}  name="fieldtype" value={e} >{e}</option>;
                 })}
             </select>
            </div> 

            {/* <div> 
            <label className="labels">Enter Field Type</label>
            <input type="text" name="fieldtype" value={this.state.fieldtype} onChange={this.setFieldTypeHandler}  placeholder="FieldType"/>
            </div> */}

            <button type="button" onClick={this.submitHandler}>confirm</button>
            </div>
        );
    }

}

export default Input;
