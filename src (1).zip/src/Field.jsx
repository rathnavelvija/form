import React from 'react';

class Field extends React.Component {
    constructor(props){
        super(props);
        this.state={
            dropDown : ' ',
        }}
    
      render() {
        return (
            <div className="row">
            <div> 
                <label className="labels">Enter Label name</label>
                <input />
            </div>  
            <div>   
            <label className="labels">Enter Field Type</label>
                <select ><option></option>
                    <option> Text Box</option>
                <option>Label</option></select>
            </div> 
            {/* <div> 
            <label className="labels">Enter Field Name</label>
                <input />
            </div>  */}
            </div>
        );
    }
}

export default Field;