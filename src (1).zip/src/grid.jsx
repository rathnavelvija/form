import React,{Component} from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { Route, Link ,Redirect,BrowserRouter as Router} from 'react-router-dom';
import Test from './Test';
import searchicon from './img/images.png';



//class Welcome extends Component{}
class dataGrid extends Component {
state={columns:[],data:[],search:'',offsetvalue:0, headerArray:[],headervalue:'',column1:[],redirect:false}

constructor(props){
    super(props);
this.nextClick=this.nextClick.bind(this);
this.backClick=this.backClick.bind(this);

}
 
nextClick(){
    const { role,formName,formId } = this.props.match.params
    console.log('next click',this.state.offsetvalue)
    

    fetch('http://localhost:8080/datagrid/'+role+'/'+this.state.offsetvalue,{method:'POST',body:JSON.stringify({formName:formName,formId:formId})})
    .then(res => res.json())
    .then((response)=>{
       console.log(response);
        this.setState({ columns: response.columns})
        this.setState({data:response.data})
       
        console.log('state is'+this.state);
        console.log('the data is'+this.state.columns[0]);
    }
    )

    this.state.offsetvalue = this.state.offsetvalue+10;

}
backClick(){
    const { role,formName,formId } = this.props.match.params
    this.state.offsetvalue = this.state.offsetvalue-10;

console.log('back click',this.state.offsetvalue)
    fetch('http://localhost:8080/datagrid/'+role+'/'+this.state.offsetvalue,{method:'POST',body:JSON.stringify({formName:formName,formId:formId})})
    .then(res => res.json())
    .then((response)=>{
       console.log(response);
        this.setState({ columns: response.columns})
        this.setState({data:response.data})

        console.log('state is'+this.state);
        console.log('the data is'+this.state.columns[0]);
    }
    )




}

componentDidMount()
{
  
    const {role, formName,formId } = this.props.match.params

    console.log('grid page',formName,formId,role)
    console.log('userid in grid',window.userId);
    fetch('http://localhost:8080/datagrid/'+role+'/'+this.state.offsetvalue,{method:'POST',body:JSON.stringify({formName:formName,formId:formId})})
    .then(res => res.json())
    .then((response)=>{
       console.log('in response grid',response);
        this.setState({ columns: response.columns})

        this.setState({data:response.data})

        this.state.columns.map((val,idx) =>{
            var val1=[];
             val1 = val.headerName;
             console.log('val1',val1)
          
        })
        this.setState({
            column1: this.state.column1.concat([{
                
               columns:response.columns,
                                                      headerName:"edit"}])});       

        console.log('in column1',this.state.column1);
        this.state.columns.map((val,index) =>
        (
            this.state.headerArray.push(val.headerName)
                
        ));
    }
    )
    this.state.offsetvalue = this.state.offsetvalue+10;
}
updateSearch(event){
    this.setState({search:event.target.value.substr(0,20)});
}
onRowClicked(event) {
    console.log('event',event);

    console.log('inside rowclicked',event.data.FIELD_ID)
 
    this.setState({redirect:true,rowId:event.data.FIELD_ID});
    console.log('event',event);
    
 //   window.alert("row " + event.node.data.ROWID + " selected = " + event.node.selected);
  }
    render()
    { 
        const { role,formName,formId } = this.props.match.params;
        console.log('form id after render',this.props.match.params.formId);
        if(this.state.redirect){
            console.log("***bef redirect in grid*",this.state.redirect);     
            console.log("***bef rowid*", this.state.rowId) ;     
			return(
               
                <Redirect to={{
                    pathname: '/DynamicForm/'+formId,
                    state: { rowId: this.state.rowId

                    }
                }}
        />
            )}

        console.log("columns:",this.state.columns);
    console.log("headerArray:",this.state.headerArray);

       let filteredData=this.state.data.filter(       
          (data)=>{let papa=this.state.columns[0].headerName;
        //  console.log("qwerty"+papa.type)
         return data[papa].indexOf(this.state.search)!==-1
         
          }
         
         )

      
      return (<div className="ag-theme-balham" style={ {height: '300px', marginTop:"150px",marginLeft:"400px", width: '500px'} }>
            
          <div>  <input type='text' className="searchiee" placeholder="   search" value={this.state.search}  onChange={this.updateSearch.bind(this)}></input>
            <button>In DB</button>
          </div>
            <AgGridReact
            
            columnDefs={this.state.columns}
            rowData={filteredData}
            pagination={true}
            onRowClicked={this.onRowClicked.bind(this)}
            >
             
        </AgGridReact>
        <div style={{marginTop:"20px"}}>
        <button className="btn-info " style={{marginLeft:"10px"}} onClick={this.backClick}>back</button>
        <button className="btn-info " style={{ marginLeft:"400px" }} onClick={this.nextClick}>next</button>
        </div>
      </div>);
    }



}export default dataGrid

