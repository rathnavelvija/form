import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';


var icon = (props) =>
{
    
const url =  "viewGrid/" +props.role +"/"  + props.formName + "/" + props.formId;
const url1 =  "dynamicForm/"  + props.formId;
console.log('role in icon',props.role);
//this.props.gridTrigger(this.props.formId,this.props.formName);

return(
    <div className="item1">
        <div className="text-center">{props.formName} </div>
        
    <center>
    <button className="btn btn-sm text-center btn-primary btn11" onClick={()=>{props.click(props.formName, props.formId)}}><a href={url} style={{color:"white"}}>View / Edit</a></button>
    <button style={{marginLeft:"10px"}} className="btn btn-sm text-center btn-primary btn11" onClick={()=>{props.click(props.formName, props.formId)}}><a href={url1} style={{color:"white"}}>Insert</a></button>


    
        </center>                     
</div>
);

}

export default icon;

