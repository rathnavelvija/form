import React, { Component } from 'react';
import Dialog from 'react-bootstrap-dialog'
import Landing from './Landing';

//import InputTextField from './InputField'
//import './App.css';
class DynamicForm extends Component {
  constructor(){
    super();
    this.state  = {
        formJson : [],
        dataReady : false,title:'',
        formData :{}, 
        form:'',
        formName:'',
        fieldData:[],
        obj:[],
        rowId:'',
        results:[],
    
    };
    
    this.formSubmitHandler = this.formSubmitHandler.bind(this);}
    componentDidMount(){


let baseUrl = "http://localhost:8080/form";
let formId = this.props.match.params.formId;
let rowID = (this.props.location.state && this.props.location.state.rowId !== undefined) ?  this.props.location.state.rowId : null
console.log(formId)
let formJson;
if ( formId && rowID ) {
    baseUrl = `${baseUrl}/${formId}/${rowID}`;
} else if (formId) {
    baseUrl = `${baseUrl}/${formId}`;
}

fetch(baseUrl, {
    method : "GET"
})
.then(response => response.json())
.then(response => {
    formJson = response;
    this.setState((state) => {
        state.formJson = formJson
     })
    this.setState({dataReady : true});
    console.log('json1',this.state.formJson)
})


        

    }
    
      
        handleChange(event) {
         // this.setState({[event.currentTarget.name]: event.target.value})
          
         console.log(event, event.currentTarget.name)
          const qwerty = event.target.value;
   
        this.setState((state) => {
        
          console.log("this.state.formData **", this.state.formData);
        
        })
           const form=[...this.state.formData[event.currentTarget.name] = qwerty ];
        console.log('FormName',this.state.formJson.formName);
      this.setState({formName:this.state.formJson.formName},()=>console.log('dsfsdf',this.state.formName));
      
      }

    formSubmitHandler(event){
      const form=this.state.formName;
      console.log(form);
      var obj = new Object();
      obj.formName=this.state.formName;
      obj.results=this.state.formData;
      console.log('in submit',obj)
            this.dialog.show({
                body: 'Are you sure want to submit the form?',
                actions: [
                  Dialog.CancelAction(),
                  Dialog.OKAction(() => {
                    console.log('ok clicked');
                    fetch('http://localhost:8080/formdata',{method:'POST',body:JSON.stringify(obj)})
                    .then(response => response)     
                    .then((response) =>{
                        console.log(response)
                        console.log('response in dymanic',response.status)
                        if(response.status===200){
                         // this.dialog.showAlert('Hello Dialog!')
                          this.dialog.show({
                              body: 'Form submitted successfully',
                              actions: [
                                Dialog.OKAction(() => {
                                  console.log('ok ok clicked');
                              })
                              ],
                            })
                        }
                      })  
                })
                ],
              })
          

     event.preventDefault();
    }

  
    render() {
        var display = null;
        return (	

            <div style={{marginTop:"100px"}}>
                
                    {this.state.dataReady}                     
                    {
                        this.state.dataReady ? (
                            <div >
        <div className="formName" >< h1 style={{textAlign:'center',color:'blue'}}>
            {this.state.formJson.formName}</ h1></div>
        {this.state.formJson.formSectionInfo.map((field) => {
            console.log(this.state.formJson.formSectionInfo);
            return (
                <div className="container">
                    {/* <h4>{field.sectionName}</h4> */}
                   
                    <legend style={{backgroundColor: '#4682B4',color:'white',width:'100%'}}><h4 style={{fontFamily: 'sans-serif', paddingLeft: '10px',color:'white',fontSize:'18px'}}>{field.sectionName}</h4></legend>
                    {field.formFieldInfo.map((ff) => {
                        
                        console.log('fields inside nested for', field.formFieldInfo);
                        if (ff.fieldLabeL === 'TEXTBOX')console.log('fieldLabeL',ff.fieldLabeL); {
                            return (
                              
                                <row style={{}}>
                              <label className="labelcss" key={ff.formFieldId}>{ff.fieldName}</label>
                                <input type="text" className="inputcss" name={ff.fieldName} value={ff.fieldValue} onBlur={this.handleChange.bind(this)}/>
                                
                                </row>
                               
                           )
                        }    
                    })}
                </div>
            )
        }
        )
        }
          <div className="text-center" > <button  className="btn btn-info buttoncss" onClick={this.formSubmitHandler}>Submit</button></div>
          <Dialog ref={(el) => { this.dialog = el }} />


    </div>
                        ) : (<div>Nothing</div>)
                    }    
                        
                    
                
                
            </div>
        )
    }
}
export default DynamicForm;

// formJson={
    //     "formId": 1,
    //     "formName": "StudentForms",
    //     "fieldValues": null,
    //     "formSectionInfo": [
    //       {
    //     "sectionId": 1,
    //     "sectionName": "BASIC DETAILS",
    //     "formFieldInfo": [
    //       {
    //     "formFieldId": 1,
    //     "fieldLabeL": "FIRST NAME",
    //     "fieldName": "FIRSTNAME",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     },
    //       {
    //     "formFieldId": 2,
    //     "fieldLabeL": "LAST NAME",
    //     "fieldName": "LASTNAME",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     }
    //     ],
    //     },
    //       {
    //     "sectionId": 2,
    //     "sectionName": "ADDRESS DETAILS",
    //     "formFieldInfo": [
    //       {
    //     "formFieldId": 3,
    //     "fieldLabeL": "ADDRESS",
    //     "fieldName": "ADDRESS",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     },
    //       {
    //     "formFieldId": 4,
    //     "fieldLabeL": "STREET",
    //     "fieldName": "STREET",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     }
    //     ],
    //     },
    //       {
    //     "sectionId": 3,
    //     "sectionName": "EDUCATION DETAILS",
    //     "formFieldInfo": [
    //       {
    //     "formFieldId": 5,
    //     "fieldLabeL": "MARKS",
    //     "fieldName": "MARKS",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     },
    //       {
    //     "formFieldId": 6,
    //     "fieldLabeL": "GRADE",
    //     "fieldName": "GRADE",
    //     "fieldValue": null,
    //     "fieldTypeName": "TEXTBOX",
    //     "fieldTypeInfo": {
    //     "fieldTypeId": 11,
    //     "fieldTypeName": "TEXTBOX"
    //     },
    //     "fieldConstraintInfos": [],
    //     "fieldRightsInfos": [],
    //     }
    //     ],
    //     }
    //     ],
    //     }


//         display = <div style={{marginTop:"100px"}}>
// <div className="container container-border">    <h2 className="text-center formNamecss">    {this.formJson.formName}</h2>
//         {this.formJson.formSectionInfo.map((field) => {
//             return (
//                 <div className="container sectionborder">
//                     <h4>{field.sectionName}</h4>
//                     {field.formFieldInfo.map((ff) => {
//                         if (ff.fieldTypeName === 'TEXTBOX') {
//                             return (<row>
//                                 <label className="labelcss">{ff.fieldLabeL} : </label>
//                                 <input className="inputcss" type="text" name={ff.fieldName} onBlur={this.handleChange.bind(this)}/>
//                             </row>)
//                         }
//                     })}

//                 </div>
//             )
//         }
//         )
//         }
//        <div className="text-center" > <button  className="btn btn-info buttoncss" onClick={this.formSubmitHandler}>Submit</button></div>
//         </div>
//     </div>
      
  
        

    //     return (
    //         <div>
                
    //                 {this.state.dataReady}                     
    //                 {
    //                     this.state.dataReady ? (
    //                         <div>
    //     <div className="formName" >< h1 style={{textAlign:'center',color:'blue'}}>
    //         {this.state.formJson.formName}</ h1></div>
    //     {this.state.formJson.formSectionInfo.map((field) => {
    //         console.log(this.state.formJson.formSectionInfo);
    //         return (
    //             <div className="container">
    //                 {/* <h4>{field.sectionName}</h4> */}
                   
    //                 <legend style={{backgroundColor: '#4682B4',color:'white',width:'100%'}}><h4 style={{fontFamily: 'sans-serif', paddingLeft: '10px',color:'white',fontSize:'18px'}}>{field.sectionName}</h4></legend>
    //                 {field.formFieldInfo.map((ff) => {
                        
    //                     console.log('fields inside nested for', field.formFieldInfo);
    //                     if (ff.fieldLabeL === 'TEXTBOX')console.log('fieldLabeL',ff.fieldLabeL); {
    //                         return (
                              
    //                             <row>
    //                           <label style={{paddingLeft:"20px"}} key={ff.formFieldId}>{ff.fieldName}</label>
    //                             <input type="text" style={{paddingLeft:"10px"}} key={ff.formFieldId}/>
                                
    //                             </row>
                               
    //                        )
    //                     }    
    //                 })}
    //             </div>
    //         )
    //     }
    //     )
    //     }
    // </div>
    //                     ) : (<div>Nothing</div>)
    //                 }    
                        
                    
                
                
    //         </div>
    //     )
//     return(
// <div>{display}</div>)
//     }
// }
// export default DynamicForm;

// import React, { Component } from 'react';
// import Header from './Header';
// import 'bootstrap/dist/css/bootstrap.css';
// import './DynamicForm.css';


// class DynamicForm extends Component {
//     constructor(props) {
//         super(props)

//         this.state = {
                 
//         }
//     }

//     render() {
//         return (
//             <div>
//                 <Header/>
//                 <form action="">
//                     <div className="Container"><h3 style={{textAlign:'center'}}>My Form</h3></div>
//                 <div style= {{border: '1px groove #eee', boxShadow: '0px 5px 5px #ccc', marginBottom:'50px'}}className="container sectionborder">
                
//                 <div className="container" id="section1">
//                 <legend style={{backgroundColor: '#4682B4',color:'white',width:'100%'}}><h4 style={{fontFamily: 'sans-serif', paddingLeft: '10px',color:'white',fontSize:'18px'}}>Personal Details</h4></legend>
//                     <div className="row direction">
//                     <div>
//                         <label htmlFor="firstname" className="fontsize">First Name:</label>
//                         <input type="text" name="firstname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="middlename">Middle Name:</label>
//                         <input type="text" name="middlename" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     </div>
//                     <div className="row">
//                     <div>
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                 </div>
//                 </div>
//                 </div>
//                 <div style= {{border: '1px groove #eee', boxShadow: '0px 5px 5px #ccc',marginBottom:'50px'}}className="container">
                
//                 <div className="container" id="section1">
//                 <legend style={{backgroundColor: '#4682B4',color:'white',width:'100%'}}><h4 style={{fontFamily: 'sans-serif', paddingLeft: '10px',color:'white',fontSize:'18px'}}>Personal Details</h4></legend>
//                     <div className="row direction" style={{padding:'15px'}}>
//                     <div>
//                         <label htmlFor="firstname" className="fontsize">First Name:</label>
//                         <input type="text" name="firstname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="middlename">Middle Name:</label>
//                         <input type="text" name="middlename" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div>
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     </div>
//                     <div className="row direction">
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                 </div>
//                 </div>
//                 </div>
//                 <div style= {{border: '1px groove #eee', boxShadow: '0px 5px 5px #ccc',marginBottom:'50px'}}className="container">
                
//                 <div className="container" id="section1">
//                 <legend style={{backgroundColor: '#4682B4',color:'white',width:'100%'}}><h4 style={{fontFamily: 'sans-serif', paddingLeft: '10px',color:'white',fontSize:'18px'}}>Personal Details</h4></legend>
//                     <div className="row direction">
//                     <div className="fieldpadding">
//                         <label htmlFor="firstname" className="fontsize">First Name:</label>
//                         <input type="text" name="firstname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="middlename">Middle Name:</label>
//                         <input type="text" name="middlename" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     </div>
//                     <div className="row">
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                     <div className="fieldpadding">
//                         <label htmlFor="lastname">Last Name:</label>
//                         <input type="text" name="lastname" style={{border:'1px solid black'}}></input>
//                     </div>
//                 </div>
//                 </div>
//                 </div>
                
//                 </form>
//             </div>
//         )
//     }
// }

// export default DynamicForm;
