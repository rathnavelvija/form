import React,{Component} from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import Icon from './Icon';
import { Route, Link ,Redirect,BrowserRouter as Router} from 'react-router-dom';
import Test from './Test';
import logincopy from './logincopy';
import Admin from './admin';

window.setGlobal = function(variable, value){
  console.log('var in window',variable);
  console.log('val in window',value);
  window[variable] = value;
  window.$userid = value;
  console.log('window', window.$userid  );
  
}

class Landing extends Component {
  constructor(props){
    super(props);

  }
  state = {forms:[], role : ''};
  
    
    rolename(role){
      this.setState({role : role}, ()=> { console.log('rolename',role)})
    }
  clicked(name, id)
  {
   

 } 
     
//  clickRedirection(name, id)
//  {
//     fetch('https://jsonplaceholder.typicode.com/posts',{method:'POST',body:JSON.stringify({formName:name,formId:id})})
//    .then(response => response.json())
//    .then(json => console.log(name)) 

// } 

 componentDidMount() {
  var self = this;
  let sections;
  let haha;
  let landingrole;

  console.log('role name in landing from props',this.props.location.state.role);
//   console.log('role name in landing match param',this.props.match.params.role);
// console.log('role name in landing',this.props.match.params.role);
// console.log('role name in landing',this.state.role1);

console.log(<logincopy roletrigger={this.rolename}/>)

window.setGlobal('userId',this.props.location.state.role);

  fetch('http://localhost:8080/dashboard/'+this.props.location.state.role,{method:'GET'})
  .then(res => res.json())
  .then((response) =>{
    console.log('response',response);
    this.setState({role : response.roleName})
    window.$role = response.roleName;
    console.log(response.formList);
    sections= response.formList.map((ff,a) => { 
      return {formId: ff.formId, formName: ff.formName
      } })

      this.setState({forms : sections})
   
  
//this.setState({forms});

console.log(this.state)})
}
 
    render() {
        return (
          <div  >
            
          <div>{(this.state.role==="Admin")?admin(this.props.location.state.role):null}</div>
          
            <div > {(this.state.role==="Admin")?  <div className="container22">
            {
            this.state.forms.map(x=>{
                  return <Admin formName={x.formName} formId={x.formId} click={this.clicked} key={x.formId}/>
                })}</div>
                :
                <div className="container23">
                  {this.state.forms.map(x=>{
                  return  <Icon role={this.props.location.state.role} formName={x.formName} formId={x.formId} click={this.clicked} key={x.formId}/>
                })}</div>
            }
            </div>
            </div>
        );
        }
      

  }
  
export default Landing;

function admin(role)
{
  console.log('in admin role',role)
  const url1 =  "create/" + role ;

  return (
    <div className="formbtn">
     
           <button className="btn-primary" > <a href={url1} style={{color:"white"}}>Create New Form</a>
          {/*<Link style={{color:"white"}}  to={{
                    pathname: '/create',
                    state: { landrole:role}
                }}> Create new Form</Link> */}
                </button> 

        </div>
  )
}

