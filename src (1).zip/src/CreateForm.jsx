import React,{Component} from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { Route, Switch, Link ,Redirect, BrowserRouter as Router} from 'react-router-dom';
import Section from './Section';
import Dialog from 'react-bootstrap-dialog';



class CreateForm extends Component{
          
    constructor(props){
        super(props);
        this.state={
            formName : ' ',
            childsecname:'',
            childfieldtype:'',
            childfieldname:'',    
            childfieldarray:[],
           inputList1: [],
           redirect:false,
            fields:[],
            role:'',
            dropDown:'',
            landrole:'',
            sections:[],
           fieldhandler:[{fieldname: "",fieldtype: ""}],        
        };
        this.clickHandler = this.clickHandler.bind(this);
        this.handleFormname =this.handleFormname.bind(this);
        this.handleSecname=this.handleSecname.bind(this);
        this.onSectionBtnClick = this.onSectionBtnClick.bind(this);
        this.sectionValues=this.sectionValues.bind(this);
    }
      
    componentDidMount(){
        var dropDown;
        //const { role } = this.props.match.params;   http://localhost:8080/drop-down
        fetch('http://localhost:8080/drop-down',{method:'GET'})
        .then(response => response.json())
        .then((response) => {
            console.log('response',response);
            dropDown = response;
           this.setState((state) => {
               state.dropDown = dropDown
            });
           console.log('dropdown',this.state.dropDown)
          });


        console.log('!!!!!!!!!!!!!!!', window.$userid );
        const userId = window.userId;

       console.log('user id in create form',userId);
    }


        sectionValues(secname,fldarray)
        {
       //   console.log("form",secname,fldname,fldtype);
    
          this.setState({childsecname :secname, childfieldarray:fldarray}, ()=> {
            // console.log("childarray in form",this.state.childfieldarray);
        });
    
    
        }
    
        
        onSectionBtnClick(event) {
           //console.log('in create role',this.props.location.state.landrole)
            const inputList1 = this.state.inputList1;    
            this.setState({
                inputList1: inputList1.concat(<Section key={inputList1.length} dropDown={this.state.dropDown} sectionConfirm={this.sectionConfirm} formtrigger={this.sectionValues} />),
            });
        }

        sectionConfirm = (secname,fieldname,fieldtype) => {
            let hasSection = false;
            let sections=[];
    
             this.state.sections.map((val,index) => {
                if(val.sectionName===secname) {
                    hasSection = true;
                    val.fields = [...val.fields,{fieldname,fieldtype}];
                    sections.push(val);
                } else {
                    sections.push(val);
                }
            })
    
            if(!hasSection) {
                sections=[...this.state.sections,{sectionName:secname,fields:[{fieldname,fieldtype}]}];
            } 
            this.setState({sections});
    
            console.log("sections in form",sections);
        }
    handleFormname(event)
    {
        this.setState({formName: event.target.value});
    
    
    }
    
    
    clickHandler(event){  
            event.preventDefault();
    
            var obj1 = new Object();
    obj1.formName=this.state.formName;
    obj1.sections=this.state.sections;
  
    console.log(obj1);
    this.dialog.show({
        body: 'Are you sure want to create the form?',
        actions: [
          Dialog.CancelAction(),
          Dialog.OKAction(() => {
            console.log('ok clicked');
            fetch('http://localhost:8080/form/112',{method:'POST',body:JSON.stringify(obj1)})
            .then(response => response)
           .then( (response) =>{console.log('response in create form',response)
           if(response.status===200){
            // this.dialog.showAlert('Hello Dialog!')
             this.dialog.show({
                 body: 'Form Created successfully',
                 actions: [
                   Dialog.OKAction(() => {
                     console.log('ok ok clicked');
                     this.setState({redirect:true})
                 })
                 ],
               })
           } else{
            this.dialog.show({
                body: 'Form NOT Created successfully',
                actions: [
                    Dialog.OKAction()]})
           }
        
        }
           )
        })
        ],
      })


        }
    
    handleSecname(event)
        {
            this.setState({secname: event.target.value});
    
        }
    
        render(){
            console.log("Before redirect IN CREATE PAGE",this.state.redirect);
            if(this.state.redirect){
                console.log("****",this.state.redirect);            
                return(    
                    <Redirect to={{
                        pathname: '/landing',    
                        state: { role: '112'}
                    }} />  
                     )          
          }
    return(
    <div>
         <form className="container " style={{border:"solid",marginTop:"110px",marginBottom:"100px"}} onSubmit={this.clickHandler} > 
    <div  style={{paddingTop:"20px"}} className="text-center"><h2>Create New Form</h2></div>
        <div >
            <pre/>
        <div className="row col-sm-6">
            <label style={{paddingLeft:"10px"}}>Enter Form Name :  </label> 
            <div className="col-sm-2" margin="30%">
            <input type="text" name="formname" value={this.state.handleFormname} onChange={this.handleFormname}  placeholder="Formname"/>
        </div>
         </div>
    
        <div className="form-group">
            </div>
            <div className="container">
            <div className="row">
            <legend className="text-left"><h6>{this.state.handleSecname}</h6></legend>          
                    <button type="button" style={{marginLeft:"10px"}} className="btn-primary" onClick={this.onSectionBtnClick} value = "AddSection">Add Section</button> 
                    {this.state.inputList1.map(function(input, index) {
                    return input;
                  })}
            </div>
            </div>
    
        <div className="text-center">
        <button type="submit" style={{marginBottom:"10px"}}  className="login-btn" value="Submit" >Submit</button>
        <Dialog ref={(el) => { this.dialog = el }} />

        </div>
    
       </div>
        </form>  
          </div> 
    
    );
        }
    
    
    }
    
    
    export default CreateForm;